Emoticon
A Python package to transform or translate emoticon into text

